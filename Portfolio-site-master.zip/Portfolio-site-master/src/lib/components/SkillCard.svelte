<script lang="ts">
  import type { Skill, Tech } from "$lib/types";
  import Icon from "@iconify/svelte";

  export let skill: Skill;
</script>

<div class="rounded-xl bg-[#271c27] p-3 col-span-1">
  <div class="w-full">
    <img class="rounded-lg" src={skill.image} alt="HacktivSpace" />
  </div>

  <h1 class="font-semibold text-2xl mt-2 text-white">{skill.name}</h1>

  <!--  <p class="text-md mt-1 text-gray-400">Tech stack</p> -->

  <p
    class="text-sm mt-1.5 grid grid-cols-5 justify-items-center gap-3 text-white"
  >
    {#each skill.iconList as item}
      <a
        href={item.link}
        class=" hover:scale-110 bg-slate-700 transition rounded-xl p-2 hover:underline"
      >
        <Icon icon={item.icon} class="w-6 h-6" />
      </a>
    {/each}
  </p>
</div>
