<script>
  import AboutSection from "$lib/components/aboutSection.svelte";
  import AchivementSection from "$lib/components/achivementSection.svelte";
  import BlogsSection from "$lib/components/blogsSection.svelte";
  import EducationSection from "$lib/components/educationSection.svelte";
  import ExpSection from "$lib/components/expSection.svelte";
  import HeroSection from "$lib/components/heroSection.svelte";
  import PodcastSection from "$lib/components/podcastSection.svelte";
  import ProjectSection from "$lib/components/projectSection.svelte";
  import SkillsSection from "$lib/components/skillsSection.svelte";
</script>

<HeroSection />
<AboutSection />
<SkillsSection />
<ProjectSection />
<ExpSection />
<EducationSection />

<PodcastSection />
<BlogsSection />
<AchivementSection />
